import math
import matplotlib.pyplot as plt
import random
all_data_points_1= [(round(random.uniform(20, 55),3), round(random.uniform(20, 55),3)) for i in range(1000)]
all_data_points_2= [(round(random.uniform(45, 80),3), round(random.uniform(45, 80),3)) for i in range(1000)]
all_data_points=[]
for i in all_data_points_1:
    all_data_points.append(i)
for i in all_data_points_2:
    all_data_points.append(i)

print(len(all_data_points))
total_clusters=2
cluster_wise_data_points=[[],[]]
cluster_wise_data_points[0]=all_data_points[0:500]
cluster_wise_data_points[1]=all_data_points[500:1000]
# cluster_wise_data_points[2]=all_data_points[500:750]
# cluster_wise_data_points[3]=all_data_points[750:1000]
centroids=[]
# for i in range(total_clusters):
#     centroids.append((round(random.uniform(0, 100),3), round(random.uniform(0, 100),3)))
centroids.append(all_data_points[159])
centroids.append(all_data_points[1142])
# centroids.append(all_data_points[431])
# centroids.append(all_data_points[431])
def update_centroids(all_clusters_data_points):
    centroids=[]
    for i in all_clusters_data_points:
        if i:
            x_value = 0
            y_value = 0
            for j in i:
                x_value += j[0]
                y_value += j[1]
            x_value = x_value / len(i)
            y_value = y_value / len(i)
            centroids.append((round(x_value,3),round(y_value,3)))
        else:
            centroids.append((0,0))
    return centroids
def plot(centroids, cluster_wise_data_points):
    colors=['red','yellow','green','blue']
    for i in range(total_clusters):
        if cluster_wise_data_points[i]:
            plt.scatter(*zip(*cluster_wise_data_points[i]),color=colors[i], label=f'Cluster{i}')
            plt.scatter(*centroids[i], color=colors[i], marker='x', label=f'Centroid{i}')
    plt.legend()
    plt.show()
plot(centroids,cluster_wise_data_points)
older_mean=[]
new_mean=['N']

while older_mean!=new_mean:
    # cluster1_data_points, cluster2_data_points = [], [].....
    cluster_wise_data_points=[]
    for _ in range(total_clusters):
        cluster_wise_data_points.append([])
    print('Older Mean',older_mean)
    print("New Mean ", new_mean)
    print()
    for j in all_data_points:
        distances = []
        for i in centroids:
            distances.append(math.sqrt(((j[0]-i[0])**2)+((j[1]-i[1])**2)))
        min_index=distances.index(min(distances))
        cluster_wise_data_points[min_index].append(j)

    older_mean=new_mean
    centroids=update_centroids(cluster_wise_data_points)
    new_mean=centroids
    plot(centroids, cluster_wise_data_points)
