import numpy
import pandas as pd
import math
import matplotlib.pyplot as plt
from scipy.stats import multivariate_normal
from sklearn.model_selection import train_test_split
df = pd.read_excel('diabetes.csv.xlsx')
features=list(df.columns[df.columns!="Outcome"])
for i in features:
    if i!='Pregnancies':
        df[i] = df[i].replace(0, df[i].mean())

def get_mean(individual_matrices,unique_classes, features):
    means={}
    for j in range(len(individual_matrices)):
        mean_values=[]
        for i in features:
            mean=individual_matrices[j][i].mean()
            mean_values.append(mean)
        means[unique_classes[j]]=mean_values
    return means
def get_variance(individual_matrices,unique_classes, features):
    variances={}
    for j in range(len(individual_matrices)):
        variance=[]
        for i in features:
            var=individual_matrices[j][i].var()
            variance.append(var)
        variances[unique_classes[j]]=variance
    return variances
def get_prior_probabilities(individual_matrices, unique_classes):
    prior_probabilities = {}
    for j in range(len(unique_classes)):
        sum = 0
        for i in range(len(unique_classes)):
            sum += len(individual_matrices.get(unique_classes[i]))
        prior_probabilities[unique_classes[j]] = len(individual_matrices.get(unique_classes[j])) / sum
    return prior_probabilities
def get_likelihood(new_feature_values):
    euler_num = 2.71828
    likelihoods={}
    for j in range(len(individual_matrices)):
        # print(means.get(j))
        likelihood=[]
        for i in range(len(features)):
            part1 = euler_num ** (-(new_feature_values[i] - means.get(j)[i]) ** 2 / (2 * (variances.get(j)[i])))
            part2 = math.sqrt(2 * 3.14 * variances.get(j)[i])
            likelihood.append(part1/part2)
        likelihoods[unique_classes[j]]=likelihood
    return likelihoods
def get_posterior_probability():
    posterior_probabilities={}
    for i in range(len(unique_classes)):
        my_likelihood=1
        for j in range(len(likelihoods[unique_classes[i]])):
            my_likelihood*=likelihoods.get(unique_classes[i])[j]
        posterior_probabilities[unique_classes[i]]=prior_probabilities[unique_classes[i]]*my_likelihood
    return posterior_probabilities
def normalize(posterior_probabilities):
    normalized_posterior_probabilities={}
    evidence=0
    for i in range(len(unique_classes)):
        evidence+=posterior_probabilities.get(unique_classes[i])
    for i in range(len(unique_classes)):
        normalized_posterior_probabilities[unique_classes[i]]=posterior_probabilities.get(unique_classes[i])/(evidence)
    return normalized_posterior_probabilities


def get_testing_feature_values(testing_set):
    feature_values_list = []
    outcomes_list = []
    for index, row in testing_set.iterrows():
        feature_values = []
        for feature in features:
            feature_values.append(row[feature])
        outcome = row["Outcome"]
        feature_values_list.append(feature_values)
        outcomes_list.append(outcome)
    return feature_values_list, outcomes_list
real, the_predictions=[],[]
print ("2 Fold Cross Validation")
k=2
while k>0:
    training_set, testing_set = train_test_split(df, test_size=0.3)
    unique_classes=numpy.unique(training_set['Outcome'])
    individual_matrices={}
    for i in range(len(unique_classes)):
        individual_matrices[unique_classes[i]]=training_set[training_set['Outcome']==unique_classes[i]]
    means=get_mean(individual_matrices, unique_classes, features)
    variances=get_variance(individual_matrices, unique_classes, features)
    prior_probabilities=get_prior_probabilities(individual_matrices, unique_classes)
    feature_values_list, outcomes=get_testing_feature_values(testing_set)
    correct_predictions=0
    the_predictions=[]
    real=[]
    for i in range(len(feature_values_list)):
        likelihoods=(get_likelihood(feature_values_list[i]))
        posterior_probabilities=get_posterior_probability()
        normalized_posterior_probabilities=normalize(posterior_probabilities)
        if normalized_posterior_probabilities.get(unique_classes[0])>=normalized_posterior_probabilities.get(unique_classes[1]) and (outcomes[i])==0:
            correct_predictions+=1
        elif normalized_posterior_probabilities.get(unique_classes[1])>=normalized_posterior_probabilities.get(unique_classes[0]) and (outcomes[i])==1:
            correct_predictions+=1
        else:
            pass

        if normalized_posterior_probabilities.get(unique_classes[0]) >= normalized_posterior_probabilities.get(unique_classes[1]):
            the_predictions.append(0)
        else:
            the_predictions.append(1)
        real.append(outcomes[i])
    print(the_predictions)
    print(real)
    print("Accuracy Of this Model is ",(correct_predictions/len(testing_set))*100,"%")
    k-=1


from sklearn.metrics import confusion_matrix
import seaborn as sns
y_true = numpy.array(real)
y_pred = numpy.array(the_predictions)


cm = confusion_matrix(y_true, y_pred)

# Plot the confusion matrix using seaborn
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=numpy.unique(y_true), yticklabels=numpy.unique(y_true))
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()
