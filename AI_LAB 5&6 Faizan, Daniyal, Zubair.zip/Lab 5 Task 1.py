import math
import matplotlib.pyplot as plt
c0_age=[25,35,45,20,35,52]
c1_age=[23,40,60,48,33]
c0_loan=[40000,60000,80000,20000,120000,18000]
c1_loan=[95000,62000,10000,220000,150000]
all_classes=['c0','c1']


def plot(color):
    plt.scatter(c0_age, c0_loan, color='green', label='Not a Defaulter')
    plt.scatter(c1_age, c1_loan, color='red', label='Defaulter')
    plt.scatter(new_sample_age, new_sample_loan, label='New Entry', marker='x', color=color)
    plt.xlabel('Age')
    plt.ylabel('Loan')
    plt.title('Data and New Entry Visualization')
    plt.legend()
    plt.show()


def get_mean(values):
    sum=0
    for i in values:
        sum+=i
    average=sum/len(values)
    return average
def get_variance(values, mean):
    variance=0
    for i in values:
        variance+=(i-mean)**2
    variance=variance/(len(values)-1)
    return variance


mean_age_c0=get_mean(c0_age)
mean_age_c1=get_mean(c1_age)

mean_loan_c0=get_mean(c0_loan)
mean_loan_c1=get_mean(c1_loan)

variance_age_c0=get_variance(c0_age, mean_age_c0)
variance_age_c1=get_variance(c1_age, mean_age_c1)

variance_loan_c0=get_variance(c0_loan, mean_loan_c0)
variance_loan_c1=get_variance(c1_loan, mean_loan_c1)

#Here we calculate prior probabilities of both the classes.
prior_prob_c0=len(c0_age)/(len(c0_age)+len(c1_age))
prior_prob_c1=len(c1_age)/(len(c0_age)+len(c1_age))

def get_input():
    new_sample_age=input("Enter Age")
    new_sample_loan=input("Enter Loan")
    try:
        new_sample_age=float(new_sample_age)
        new_sample_loan=float(new_sample_loan)
        return new_sample_age, new_sample_loan
    except:
        print("Invalid")
        get_input()

new_sample_age, new_sample_loan=get_input()

#Here we calculate posterior probability of class 0
def get_likelihood(variance,new_feature_value, mean):
    euler_num=2.71828
    part1=euler_num**(-(new_feature_value-mean)**2/(2*(variance)))
    part2=math.sqrt(2*3.14*variance)
    return(part1/part2)
likelihood_age_c0=get_likelihood(variance_age_c0, new_sample_age, mean_age_c0)
likelihood_age_c1=get_likelihood(variance_age_c1, new_sample_age, mean_age_c1)
likelihood_loan_c0=get_likelihood(variance_loan_c0, new_sample_loan, mean_loan_c0)
likelihood_loan_c1=get_likelihood(variance_loan_c1, new_sample_loan, mean_loan_c1)

# Here we calculate evidence
def calculate_evidence(p1, p2):
    return p1+p2
def normalize(posterio_probability, evidence):
    return posterio_probability/evidence

# evidence=calculate_evidence(prior_prob_c0, prior_prob_c1, likelihood_c0, likelihood_c1)
#Here we find out posterior probability of the classes:
def get_posterior_probability(prior_probability, likelihood_age, liklihood_loan):
    return prior_probability*likelihood_age*liklihood_loan

posterior_prob_c0=get_posterior_probability(prior_prob_c0, likelihood_age_c0, likelihood_loan_c0)
posterior_prob_c1=get_posterior_probability(prior_prob_c1, likelihood_age_c1, likelihood_loan_c1)

evidence=calculate_evidence(posterior_prob_c0, posterior_prob_c1)
normalize_posterior_prob_c0=normalize(posterior_prob_c0, evidence)
normalize_posterior_prob_c1=normalize(posterior_prob_c1, evidence)

if normalize_posterior_prob_c0>normalize_posterior_prob_c1:
    print("This Person Belongs to Class 0 \nWith ", normalize_posterior_prob_c0, " probability")
    plot('green')
else:
    print("This Person Belongs to Class 1 \nWith ", normalize_posterior_prob_c1, " probability")
    plot('red')


