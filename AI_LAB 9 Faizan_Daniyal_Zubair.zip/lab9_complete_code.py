# Make Follwing changes To acheive the Functionality of Task 1: (undirected graph)
        # 1. Uncomment Line 27
        # 2. change line 13 as nx_graph=nx.Graph()
        # 3. update the node values (optional)

import networkx as nx
import matplotlib.pyplot as plt
class Node:
    def __init__(self, data):
        self.data=data
class Graph:
    adj_list={}
    nx_graph=nx.DiGraph()
    def add_vertex(self, data):
        if data in self.adj_list:
            print("Node Already exist")
            return
        n=Node(data)
        self.adj_list[n.data]=[]
        self.nx_graph.add_node(data)
    def add_edge(self, fromm, too):
        if fromm in self.adj_list[too] or too in self.adj_list[fromm]:
            print("Edge already exists")
            return
        if fromm in self.adj_list and too in self.adj_list:
            self.adj_list[fromm].append(too)
            # self.adj_list[too].append(fromm)
            self.nx_graph.add_edge(fromm, too)
        else:
            print("Node does not exist")
            return

    def find_any_single_path(self, start, goal):
        if start not in self.adj_list or goal not in self.adj_list:
            print("Node does not exist")
            return
        stack=[]
        visiting_list=[]
        # start=list(self.adj_list.keys())[0]
        stack.append(start)
        while stack:
            rem=stack.pop()
            if rem==goal:
                print("Goal Node Achieved")
                visiting_list.append(rem)
                print("The path is", visiting_list)
                return
            if rem not in visiting_list:
                visiting_list.append(rem)
                print(rem)
                for i in self.adj_list[rem]:
                    stack.append(i)

    def find_all_paths(self, start, goal,path):
        if start not in self.adj_list or goal not in self.adj_list:
            print("Node does not exist")
            return

        path = path + [start]

        if start == goal:
            print("Goal Node Achieved")
            print("The path is", path)
            return

        for neighbor in self.adj_list[start]:
            if neighbor not in path:
                self.find_all_paths(neighbor, goal, path.copy())
    def cal_indegree(self,key):
        in_degree=0
        for i in self.adj_list:
            if key in self.adj_list[i]:
                in_degree+=1
        return in_degree
    def show_content(self):
        for i in self.adj_list:
            print(f"Connection of Node {i} are {self.adj_list[i]}")
            print(f"Out Degree of Node {i} is {len(self.adj_list[i])}")
            print(f"IN- Degree of Node {i} is {self.cal_indegree(i)}")

    def show_graph(self):
        # pos = nx.spring_layout(self.nx_graph)
        nx.draw(self.nx_graph, with_labels=True, node_color='grey', edge_color='r', font_weight='light')
        plt.show()
gr=Graph()
nodes=['A','B','C','D','E','F','G']

for i in nodes:
    gr.add_vertex(i)
gr.add_edge('A', 'B'), gr.add_edge('B', 'C'), gr.add_edge('B', 'E'), gr.add_edge('B', 'D'), gr.add_edge('G', 'E'), gr.add_edge('C', 'E'), gr.add_edge('D','E'), gr.add_edge('G','D'), gr.add_edge('E','F')
gr.find_any_single_path('A', 'F')
gr.find_all_paths('A','F',[])
gr.show_content()
gr.show_graph()
