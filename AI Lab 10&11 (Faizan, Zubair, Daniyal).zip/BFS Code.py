import networkx as nx
import matplotlib.pyplot as plt
class Node:
    def __init__(self, data):
        self.data = data

class Graph:
    def __init__(self):
        self.adj_list = {}
        self.nx_graph = nx.Graph()

    def add_vertex(self, data):
        if data in self.adj_list:
            print("Node Already exists")
            return

        node = Node(data)
        self.adj_list[node.data] = []
        self.nx_graph.add_node(data)

    def add_edge(self, from_node, to_node):
        if from_node in self.adj_list[to_node] or to_node in self.adj_list[from_node]:
            print("Edge already exists")
            return

        if from_node in self.adj_list and to_node in self.adj_list:
            self.adj_list[from_node].append(to_node)
            self.adj_list[to_node].append(from_node)
            self.nx_graph.add_edge(from_node, to_node)
        else:
            print("Node does not exist")
            return
    def BFS(self,start):
        quaue=[start]
        visited=[]
        while quaue:
            x=quaue.pop(0)
            print(x)
            visited.append(x)
            for i in self.adj_list[x]:
                if i not in visited and i not in quaue:
                    quaue.append(i)
        return visited


    def show_graph(self,start_node):
        order=self.BFS(start_node)
        traversal_text = f"Starting Node = {start_node}\n"+"BFS Traversal Order\n"+"\n".join(map(str,order))
        text_to_display = f"{traversal_text}"

        nx.draw(self.nx_graph, with_labels=True, node_color='grey', edge_color='r', font_weight='light')
        plt.text(0.02, 0.98, text_to_display, transform=plt.gca().transAxes, fontsize=10, verticalalignment='top',
                 bbox=dict(facecolor='white', alpha=0.5))
        plt.show()


gr = Graph()
nodes = ["A","B",'C','D','E']

for node in nodes:
    gr.add_vertex(node)

gr.add_edge('A','B')
gr.add_edge('A','E')
gr.add_edge('A','D')
gr.add_edge('B','D')
gr.add_edge('D','C')
gr.add_edge('E','B')
# gr.add_edge(4,6)
# print(gr.adj_list)
# gr.BFS('E')
gr.show_graph(6)

