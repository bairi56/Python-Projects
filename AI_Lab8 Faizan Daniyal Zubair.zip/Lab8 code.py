
import statistics
import numpy as np
import matplotlib.pyplot as plt

class1 = {"x1": [4, 2, 2, 3, 4], "x2": [2, 4, 3, 6, 4]}
class2 = {"x1": [9, 6, 9, 8, 10], "x2": [10, 8, 5, 7, 8]}

plt.scatter(class1["x1"], class1["x2"], label='Class 1', marker='o', color="blue")
plt.scatter(class2["x1"], class2["x2"], label='Class 2', marker='*', color="red")
plt.xlabel('X Axis')
plt.ylabel('Y Axis')
plt.title('Without LDA Projection')
plt.legend()
plt.show()

mean_class1 = {}
mean_class2 = {}

for c1, c2 in zip(class1, class2):
    mean_class1[c1] = statistics.mean(class1[c1])
    mean_class2[c1] = statistics.mean(class2[c2])

print(mean_class1)
print(mean_class2)

def between_class_matrix(mean_class1, mean_class2):
    first = [mean_class1["x1"] - mean_class2["x1"], mean_class1["x2"] - mean_class2["x2"]]
    second = np.array(first)[:, np.newaxis]
    btw_class = np.zeros((len(first), len(second)))

    for i in range(len(first)):
        for j in range(len(second)):
            btw_class[i][j] = first[i] * second[j]

    print("Between class matrix is ", btw_class)
    return btw_class

Sb_matrix = between_class_matrix(mean_class1, mean_class2)
print("between classs matrix",Sb_matrix)
def co_variance_matrix():
    data_class1 = np.array([class1["x1"], class1["x2"]])
    data_class2 = np.array([class2["x1"], class2["x2"]])
    print("Class 1 data is",data_class1)
    cov_class1 = np.cov(data_class1, bias=True)
    cov_class2 = np.cov(data_class2, bias=True)

    print("Covariance matrix for class1:")
    print(cov_class1)
    print("Covariance matrix for class2:")
    print(cov_class2)

    return cov_class1, cov_class2

cov1, cov2 = co_variance_matrix()

def within_class_scatter_matrix(cov1, cov2):
    Sw = cov1 + cov2
    print("Within-class scatter matrix:")
    print(Sw)
    return Sw

Sw = within_class_scatter_matrix(cov1, cov2)

def lda_projection(Sw, Sb_matrix):
    eigvals, eigvecs = np.linalg.eig(np.linalg.inv(Sw).dot(Sb_matrix))

    # Sort eigenvectors
    idx = np.argsort(eigvals)
    #in descending order
    # idx=idx[::-1]
    # eigvecs = eigvecs[:, idx]
    # for i in eigvecs:
    #     print(i)
    x=[eigvecs[0]]
    print("----",x,'--',eigvecs[:, :1])
    # Choose projection vectors (eigenvectors)
    projection_matrix = eigvecs[:, :1]  # Choose the first eigenvector for 1D projection

    # LDA projection: Project data onto the subspace defined by the projection matrix
    data_class1 = np.array([class1["x1"], class1["x2"]])
    data_class2 = np.array([class2["x1"], class2["x2"]])
    projected_class1 = projection_matrix.T.dot(data_class1)
    projected_class2 = projection_matrix.T.dot(data_class2)
    print("Eigen vectors are: ")
    print(eigvecs)
    print("LDA Projection Matrix (W):")
    print(projection_matrix)
    print("\nProjected Class 1:")
    print(projected_class1)
    print("\nProjected Class 2:")
    print(projected_class2)

    return projected_class1, projected_class2, projection_matrix

projected_class1, projected_class2, projection_matrix = lda_projection(Sw, Sb_matrix)

def plot_final(projected_class1, projected_class2, projection_matrix):
    plt.scatter(projected_class1, np.zeros_like(projected_class1), label='Class 1', marker='o', color='blue')
    plt.scatter(projected_class2, np.zeros_like(projected_class2), label='Class 2', marker='*', color="red")
    print(projection_matrix,'kkkk')
    # Get the direction of the projection vector and plot the line passing through the origin
    projection_direction = projection_matrix[:, 0]  # Considering the first projection vector
    print(projection_direction,'kkllk')
    plt.plot([0, projection_direction[0]*10], [0, projection_direction[1]*10], color='purple', linewidth=2,
             label='Projection Line')

    plt.xlabel('Projected Axis')
    plt.title('LDA Projection with Projection Line')
    plt.legend()
    plt.grid(True)
    plt.show()

plot_final(projected_class1, projected_class2, projection_matrix)
